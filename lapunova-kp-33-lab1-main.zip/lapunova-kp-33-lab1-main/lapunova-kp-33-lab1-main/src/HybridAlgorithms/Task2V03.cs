namespace HybridAlgorithms;

public class Task2V03
{
    public int Calculate(int year)
    {
        throw new NotImplementedException();
    }
}
namespace HybridAlgorithms;

public class Task2V12
{
    public List<int> Calculate(int n)
    {
        throw new NotImplementedException();
    }
}
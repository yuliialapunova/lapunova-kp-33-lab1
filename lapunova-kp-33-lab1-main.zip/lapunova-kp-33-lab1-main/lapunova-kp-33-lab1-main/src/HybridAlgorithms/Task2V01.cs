namespace HybridAlgorithms;

public class Task2V01
{
    public int Calculate(int century)
    {
        throw new NotImplementedException();
    }
}
namespace HybridAlgorithms;

public class Task2V11
{
    public DayOfWeek Calculate(int date, int month)
    {
        throw new NotImplementedException();
    }
}
namespace HybridAlgorithms;

public class Task2V02
{
    public List<int> Calculate(int digitCount)
    {
        throw new NotImplementedException();
        int[] number;
        digitCount = 0;
        for (int i = 100; i < 100000; i++)
        {
            if (i % (i / 1000 + i % 1000 / 100 + i % 100 / 10 + i % 10) == 0)
            {
                number[digitCount] = i;
                digitCount++;
            }
        }
    }
}
namespace HybridAlgorithms;

public class Task2V13
{
    public (int dayNumber, int monthTillEndOfYear, int daysTillEndOfYear) Calculate(int day, int month, int year)
    {
        throw new NotImplementedException();
    }
}
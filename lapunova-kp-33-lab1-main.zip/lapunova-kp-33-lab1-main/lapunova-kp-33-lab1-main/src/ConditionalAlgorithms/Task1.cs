﻿namespace ConditionalAlgorithms;

public class Task1
{
    public (double x, double y) Calculate(double a, double b, double c)
    {
        throw new NotImplementedException();
        double x;
        double y;
        double z;
        x=Convert.ToDouble(Console.ReadLine);
        y=Convert.ToDouble(Console.ReadLine) ;
        z = Convert.ToDouble(Console.ReadLine);

        if (Math.Pow(x,z) * y - Math.Pow(x, 0.6) + Math.Pow(y, 0.3) * Math.Pow(z, 0.3) == 0)
        {
            Console.WriteLine("Error");
        }
        else
        {
            a = (x + y - z) / (Math.Pow(x, z) * y - Math.Pow(x, 0.6) + Math.Pow(y, 0.3) * Math.Pow(z, 0.3));
            if (a==0)
            {
                Console.WriteLine("Error");
            }
            else
            {
                b = Math.Cos((x*y+Math.Pow(y,2))/ Math.Pow(a, 2));
            }
        }
    }
}